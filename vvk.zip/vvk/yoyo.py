from tkinter import *
import requests
root = Tk()
root.maxsize(1200,600)
root.minsize(1200,800)
root.title("Weather")

def data_get(): 
     city =e_city_name.get()
     data = requests.get("https://api.openweathermap.org/data/2.5/weather?q="+ city +"&appid=cc2c52b59823e8af16fc25f51e757b72").json()
     l_e_m_t.config(text=str(data["main"]["temp_min"]-273.15))
     l_e_max_t.config(text=str(data["main"]["temp_max"]-273.15))
     


lbl_title = Label(root,text="Weather",font="arial 35 bold")
lbl_title.pack()

lbl_city_name = Label(root,text="Enter City : ",font="arial 25 bold")
lbl_city_name.place(x=170,y=150)

e_city_name = Entry(root,font="arial 22 bold",bg='aqua',width=25)
e_city_name.place(x=400,y=150)

s_city_name = Button(root,text="Submit",padx=50,pady=10,bg='lightgreen',bd=6,command=data_get)
s_city_name.place(x=850,y=148)

l_m_t = Label(root,text="Minimum Temp",font="arial 23 bold",bg='green',bd=7)
l_m_t.place(x=80,y=270)

l_e_m_t = Label(root,font="arial 26 bold",bg='aqua',width=10)
l_e_m_t.place(x=370,y=270)

l_max_t = Label(root,text="Minimum Temp",font="arial 23 bold",bg='green',bd=7)
l_max_t.place(x=660,y=270)

l_e_max_t = Label(root,font="arial 26 bold",bg='aqua',width=10)
l_e_max_t.place(x=950,y=270)

l_wind_t = Label(root,text="Wind Speed",font="arial 23 bold",bg='green',bd=7)
l_wind_t.place(x=80,y=420)

e_wind_t = Entry(root,font="arial 26 bold",bg='aqua',width=10)
e_wind_t.place(x=370,y=420)

l_hum_t = Label(root,text="Humidity",font="arial 23 bold",bg='green',bd=7)
l_hum_t.place(x=660,y=420)

e_hum_t = Entry(root,font="arial 26 bold",bg='aqua',width=10)
e_hum_t.place(x=950,y=420)

l_t = Label(root,text="Temperature",font="arial 23 bold",bg='green',bd=7)
l_t.place(x=80,y=570)

e_t = Entry(root,font="arial 26 bold",bg='aqua',width=10)
e_t.place(x=370,y=570)

l_p = Label(root,text="Pressure",font="arial 23 bold",bg='green',bd=7)
l_p.place(x=660,y=570)

e_hum_t = Entry(root,font="arial 26 bold",bg='aqua',width=10)
e_hum_t.place(x=950,y=570)

l_d = Label(root,text="Description",font="arial 26 bold")
l_d.place(x=300,y=720)

e_d = Entry(root,font="arial 26 bold",bg='aqua',width=25)
e_d.place(x=600,y=720)

mainloop()