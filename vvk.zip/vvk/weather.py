from tkinter import *

root = Tk()
root.geometry("1600x800")
root.maxsize(1600,800)

l_t = Label(root,text="Weather",font='arial 36 bold',fg= 'purple')
l_t.pack()

l_city_name = Label(root,text="Enter City : ",font='arial 26 bold')
l_city_name.place(x=380,y=150)

l_entry_name = Entry(root,width=20,font='arial 26 bold')
l_entry_name.place(x=650,y=150)

s_entry = Button(root,text="Submit",font='arial 16 bold')
s_entry.place(x=1100,y=150)




mainloop()