# import datetime
# a = datetime.datetime.now().minute

# if a > 0 and a <= 12:

#     print("good morning")

# elif a >= 12 and a < 16:
#   print("good afternoon")

# else:
#     print("good evening")
    

#     print(a) 







# from tkinter import *

# root = Tk()
# root.geometry("800x600")
# root.maxsize(800,600)
# btn = Button(root, text='Click me!', command=root.destroy)


# root["bg"] =  "pink"

# mainloop()





# lambda
# it is a small anonymous function means function without name 

# a = lambda:"hello"
# print(a())

# a = lambda name : name
# print(a("vivek"))

# a = [22,34,45,56,67,78,98,76,65,43,32,21]
# b = filter(lambda x : x < 33,a)
# for i in b :
#     print (i)





# from tkinter import *
# from tkinter.ttk import *
# import tkinter as tk

# root = tk.Tk()

# root.geometry("800x600") 
# root.maxsize(800,600)
# root["bg"] = "black"

# btn = Button(root, text='Click me!', )
# btn.place(x=350,y=300)

# label = tk.Label(root, text="Hello, World!")
# label.pack()

# root.mainloop()



from tkinter import *
from PIL import Image,ImageTk
import subprocess
def startfun():
    subprocess.call(["python","vv.py"])
root = Tk()
root.geometry("800x600")
root.maxsize(800,600)
root["bg"] = "pink"

def bgmi():
    s = Toplevel(root)
    s.geometry("800x600")
    s.maxsize(800,600)


mainmenu = Menu(root)


#file section
file = Menu(mainmenu)
mainmenu.add_cascade(label="File",menu=file)
file.add_command(label="new file",command=bgmi)
file.add_command(label="open ")
file.add_command(label="save")
file.add_command(label="save as")



#Edit section
Edit =Menu(mainmenu)
mainmenu.add_cascade(label="Edit",menu=Edit)
Edit.add_command(label="cut")
Edit.add_command(label="copy")
Edit.add_command(label="paste")

#help section
Help = Menu(mainmenu)
mainmenu.add_cascade(label="Help",menu=Help)
Help.add_command(label="chat with us")
Help.add_command(label="call us")

root.config(menu=mainmenu)



lbl_title = Label(root,text="This is my first project .",font = "TimesNewRoman  30 italic bold underline",bg="pink",fg="black")
lbl_title.pack()

frm = Frame(root,width=400,height=500)
frm.place(x=20,y=60)
    
img = ImageTk.PhotoImage(Image.open("tom.png"))
lbl_img = Label(frm,image=img,bg="pink")
lbl_img.pack()

lbl_content = Label(root,text = "welcome \n to my project \n click on start \n button",font="arial 25 bold",bg="pink",fg="black")
lbl_content.place(x=550,y=250) 


btn_s = Button(root,text="start",padx=50,pady=25,command=startfun,font="arial 10 bold italic",bg="yellow")
btn_s.place(x=150,y=500)

btn_r = Button(root,text="exit",padx=50,pady=25,command=exit,font="arial 10 bold italic",bg="yellow")
btn_r.place(x=550,y=500)

mainloop()


# import cv2

# face_cascade = cv2.CascadeClassifier('facefile.xml')
# vid = cv2.VideoCapture(0)


# while True:
#     net,frame = vid.read()
#     gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray,1.3,5)
#     for(x,y,w,h) in faces:
#         cv2.rectangle(frame,(x,y),(x+w,y+h),(255,255,0),2)

#     cv2.imshow('camera',frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break
# vid.release()
# cv2.destroyAllWindows()    