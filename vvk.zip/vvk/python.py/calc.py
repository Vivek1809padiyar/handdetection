from tkinter import *
root = Tk()
root.geometry("310x370")
root.maxsize(350,390)
root["bg"] = "light blue"

def numeric_btn(num):
    value = e.get()
    e.delete(0,END)
    e.insert(0,str(value) + str(num))
def del_data():
    e.delete(0,END)

def add():
    global add
    add = e.get() 
    global oper
    oper = "+"
    e.delete(0,END)
def sub():
    global sub
    sub = e.get() 
    global oper
    oper = "-"
    e.delete(0,END)

def mul():
    global mul
    mul = e.get()
    global oper 
    oper = "*"
    e.delete(0,END)

def div():
    global div
    div = e.get()
    global oper 
    oper = "/"
    e.delete(0,END)


def equal():
    second = e.get()
    e.delete(0,END)
    if oper == "+":
        e.insert(0,int(add)+int(second))    

    elif oper == "-":
        e.insert(0,int(sub)-int(second))

    elif oper == "*":
        e.insert(0,int(mul) * int(second))   

    elif oper == "/":
        e.insert(0,int(div)/int(second)) 




e = Entry(root,font="arial 15 bold",width = 25)
e.grid(row=1,column=1,columnspan=4)

btn_1= Button(root,text="1",padx=20,pady=20,bd=9,command=lambda:numeric_btn("1"))
btn_2= Button(root,text="2",padx=20,pady=20,bd=9,command=lambda:numeric_btn("2"))
btn_3= Button(root,text="3",padx=20,pady=20,bd=9,command=lambda:numeric_btn("3"))
btn_a= Button(root,text="+",padx=20,pady=20,bd=9,command=add)

#row 2
btn_1.grid(row=2,column=1)
btn_2.grid(row=2,column=2)
btn_3.grid(row=2,column=3)
btn_a.grid(row=2,column=4)
btn_4= Button(root,text="4",padx=20,pady=20,bd=9,command=lambda:numeric_btn("4"))
btn_5= Button(root,text="5",padx=20,pady=20,bd=9,command=lambda:numeric_btn("5"))
btn_6= Button(root,text="6",padx=20,pady=20,bd=9,command=lambda:numeric_btn("6"))
btn_s= Button(root,text="-",padx=20,pady=20,bd=9,command=sub)

#row 3
btn_4.grid(row=3,column=1)
btn_5.grid(row=3,column=2)
btn_6.grid(row=3,column=3)
btn_s.grid(row=3,column=4)
btn_7= Button(root,text="7",padx=20,pady=20,bd=9,command=lambda:numeric_btn("7"))
btn_8= Button(root,text="8",padx=20,pady=20,bd=9,command=lambda:numeric_btn("8"))
btn_9= Button(root,text="9",padx=20,pady=20,bd=9,command=lambda:numeric_btn("9"))
btn_m= Button(root,text="*",padx=20,pady=20,bd=9,command=mul)

#row 4
btn_7.grid(row=4,column=1)
btn_8.grid(row=4,column=2)
btn_9.grid(row=4,column=3)
btn_m.grid(row=4,column=4)
btn_zero= Button(root,text="0",padx=20,pady=20,bd=9,command=lambda:numeric_btn("0"))
btn_e= Button(root,text="=",padx=20,pady=20,bd=9,command=equal)
btn_d= Button(root,text="/",padx=20,pady=20,bd=9,command=div)
btn_c= Button(root,text="X",padx=20,pady=20,bd=9,command=del_data)

#row 5
btn_zero.grid(row=5,column=1)
btn_e.grid(row=5,column=2)
btn_d.grid(row=5,column=3)
btn_c.grid(row=5,column=4)
mainloop()








# btn_1 = Button(root,text="1",padx=20,pady=20,bd=9)
# btn_2 = Button(root,text="2",padx=20,pady=20,bd=9)
# btn_3 = Button(root,text="3",padx=20,pady=20,bd=9)
# btn_a = Button(root,text="+",padx=20,pady=20,bd=9)
# #row 2
# btn_1.grid(row=2,column=1)
# btn_2.grid(row=2,column=2)
# btn_3.grid(row=2,column=3)
# btn_a.grid(row=2,column=4)

# btn_4 = Button(root,text="4",padx=20,pady=20,bd=9)
# btn_5 = Button(root,text="5",padx=20,pady=20,bd=9)
# btn_6 = Button(root,text="6",padx=20,pady=20,bd=9)
# btn_s = Button(root,text="-",padx=20,pady=20,bd=9)

# btn_4.grid(row=3,column=1)
# btn_5.grid(row=3,column=2)
# btn_6.grid(row=3,column=3)
# btn_s.grid(row=3,column=4)

# btn_7 = Button(root,text="7",padx=20,pady=20,bd=9)
# btn_8 = Button(root,text="8",padx=20,pady=20,bd=9)
# btn_9 = Button(root,text="9",padx=20,pady=20,bd=9)
# btn_m = Button(root,text="*",padx=20,pady=20,bd=9)


# btn_7.grid(row=4,column=1)
# btn_8.grid(row=4,column=2)
# btn_9.grid(row=4,column=3)
# btn_m.grid(row=4,column=4)

# btn_zero = Button(root,text="0",padx=20,pady=20,bd=9)
# btn_e = Button(root,text="=",padx=20,pady=20,bd=9)
# btn_c = Button(root,text="x",padx=20,pady=20,bd=9)
# btn_d = Button(root,text="/",padx=20,pady=20,bd=9)

# btn_zero.grid(row=5,column=1)
# btn_e.grid(row=5,column=2)
# btn_c.grid(row=5,column=3)
# btn_d.grid(row=5,column=4)
# mainloop()