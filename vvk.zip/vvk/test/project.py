from tkinter import *
from PIL import Image,ImageTk
import pyttsx3 as ps
root = Tk()

root.geometry("1200x800")
root.maxsize(1200,800)
root['bg'] = "pink"
engine = ps.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def text_speech():
        value = t_entry.get(1.0,'end-1c')
        speak(value)

l_title = Label(root,text="AI SPEAKER",font='timesnewroman 40 bold underline',bg="pink")
l_title.pack()

frm = Frame(root,width=150,height=400)
frm.place(x=80,y=200)

img = ImageTk.PhotoImage(Image.open('tom.png'))
img_display = Label(frm, image=img,bg='pink')
img_display.pack()

t_entry = Text(root,width=30,height=16,font=25)
t_entry.place(x=750,y=200)

btn_submit = Button(root,text="Text to speech",padx=20,pady=9,command=text_speech,font='50',bg="skyblue")
btn_submit.place(x=450,y=600)

mainloop()